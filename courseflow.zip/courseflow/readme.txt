=== WooScan ===
Contributors: Jerry Tieben
Tags: CourseFlow, course-flow
Requires at least: 4.7
Tested up to: 6.1.1
Stable tag: 4.7
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your CourseFlow account to your WordPress website

== Description ==

Connect your CourseFlow account to your WordPress website

== Frequently Asked Questions ==

= How do i connect the plugin to my CourseFlow account?

Go to the settings page of the plugin and enter the API credentials of your CourseFlow account. You can find these on the settings page in your CourseFlow account.


== Screenshots ==


== Changelog ==

= 1.04 =
Bug fix: smilies activated in wordpress resulted in an error

= 1.03 =
Language files updated

= 1.02 =
WooCommerce extensions added.
You can now connect woocommerce products to CourseFlow flows.
After buying the user will be added to the flow immediately

= 1.0 =
CourseFlow Shop